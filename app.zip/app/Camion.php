<?php

namespace Palma;

use Illuminate\Database\Eloquent\Model;

class Camion extends Model
{
    protected $table = "camion";
}
