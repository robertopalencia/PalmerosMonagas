<?php

namespace Palma;

use Illuminate\Database\Eloquent\Model;

class Precio extends Model
{
    protected $table = "precio";
}
