<?php

namespace Palma;

use Illuminate\Database\Eloquent\Model;

class Cupos extends Model
{
    protected $table = "cupos";
}
