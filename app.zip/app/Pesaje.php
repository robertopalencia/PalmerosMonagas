<?php

namespace Palma;

use Illuminate\Database\Eloquent\Model;

class Pesaje extends Model
{
    protected $table = "pesaje";
}
