<?php

namespace Palma;

use Illuminate\Database\Eloquent\Model;

class Banco extends Model
{
    protected $table = "banco";
}
